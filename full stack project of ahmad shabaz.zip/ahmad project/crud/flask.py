from flask import Flask, request, jsonify

app = Flask(__name__)

# Dummy database for storing overlay settings
overlay_settings = []

# OverlaySetting class to represent an overlay
class OverlaySetting:
    def __init__(self, id, content, position_x, position_y, width, height):
        self.id = id
        self.content = content
        self.position_x = position_x
        self.position_y = position_y
        self.width = width
        self.height = height

# Create an overlay setting
@app.route('/overlay', methods=['POST'])
def create_overlay():
    data = request.json
    content = data.get('content')
    position_x = data.get('position_x')
    position_y = data.get('position_y')
    width = data.get('width')
    height = data.get('height')

    if not content or not position_x or not position_y or not width or not height:
        return jsonify({"message": "Missing data in the request"}), 400

    # Generate a unique ID for the new overlay
    new_id = len(overlay_settings) + 1

    # Create the overlay setting
    overlay = OverlaySetting(new_id, content, position_x, position_y, width, height)

    # Add the overlay to the database
    overlay_settings.append(overlay)

    return jsonify({"message": "Overlay setting created successfully", "id": new_id}), 201

# Read all overlay settings
@app.route('/overlay', methods=['GET'])
def read_overlays():
    overlays = []
    for overlay in overlay_settings:
        overlays.append({
            "id": overlay.id,
            "content": overlay.content,
            "position_x": overlay.position_x,
            "position_y": overlay.position_y,
            "width": overlay.width,
            "height": overlay.height
        })

    return jsonify(overlays)

# Update an overlay setting
@app.route('/overlay/<int:id>', methods=['PUT'])
def update_overlay(id):
    data = request.json
    for overlay in overlay_settings:
        if overlay.id == id:
            overlay.content = data.get('content', overlay.content)
            overlay.position_x = data.get('position_x', overlay.position_x)
            overlay.position_y = data.get('position_y', overlay.position_y)
            overlay.width = data.get('width', overlay.width)
            overlay.height = data.get('height', overlay.height)
            return jsonify({"message": "Overlay setting updated successfully"})

    return jsonify({"message": "Overlay setting not found"}), 404

# Delete an overlay setting
@app.route('/overlay/<int:id>', methods=['DELETE'])
def delete_overlay(id):
    for overlay in overlay_settings:
        if overlay.id == id:
            overlay_settings.remove(overlay)
            return jsonify({"message": "Overlay setting deleted successfully"})

    return jsonify({"message": "Overlay setting not found"}), 404

if __name__ == '__main__':
    app.run(debug=True)
